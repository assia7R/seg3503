//==============================================================================
//Calculator.java (S. Some)
//This program is largely based on  AwtCalc.java
//Author:  Ernest Criss Jr.
//==============================================================================

import javax.swing.JFrame;

public class Main {

	public static void main(String[] argv) {
    JFrame frame =
	  new CalCFrame("Calculator");
    frame.setSize(360,200);
    frame.setVisible(true);
  }
}
